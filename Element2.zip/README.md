```python

                              DATA VISUALIZATION FOR COVID AND STOP & SEARCH



AUTHOR : AVIOMOH RICHARD AGBOMIRE
    


Introduction:
This project has three main python files. The first file is the stop and searh file, the second file is the covid file and the 
third file is the Visualization file.

Covid File:
In the covid file, all the data preprocesing for covid is done on this file. 
The dataframes created is then saved using the "%store" function.

Stop_and_search file:
In the Stop and Search file, all the data for AVON and Somerset from 2019 to 2022 has been extracted and pre-processed.
The dataframes created is then saved using the "%store" function.

Visualization file:
In the Visualization file, the saved dataframes are then imported using this syntax "%store -r dataframe_name". The covid file 
and stop_and_search file must be ran before running the visualization file to ensure the stored data frames are succesfully 
imported into the visualization file.These dataframes are then used to create functions for plotting graphs for both covid and
stop and search. Then finally, a GUI is created to visualize the graphs by clicking a button. These buttons are linked to their
respective functions. 

THE GUI WAS CREATED ON A DESKTOP, SO WOULD BEST BE VIEWED USING A DESKTOP OR A COMPUTER WITH A BIG SCREEN TO GET THE BEST USER EXPERIENCE. 

```
